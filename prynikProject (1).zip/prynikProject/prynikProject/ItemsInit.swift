//
//  ItemsInit.swift
//  prynikProject
//
//  Created by Олег Ганяхин on 13.10.2020.
//

import UIKit

struct ViewResponse: Decodable {

    let view: [ViewType]
    let data: [Item]
}

enum ViewType: String, Decodable {

    case hz
    case selector
    case picture
}

struct Item: Decodable {
    let name: ViewType
    let data: Any

    enum CodingKeys: String, CodingKey {
        case name
        case data
    }

    init(from decoder: Decoder) throws {

        let container = try decoder.container(keyedBy: CodingKeys.self)

        self.name = try container.decode(ViewType.self, forKey: .name)

        switch name {
        case .hz: data = try container.decode(HzData.self, forKey: .data)
        case .picture: data = try container.decode(PictureData.self, forKey: .data)
        case .selector: data = try container.decode(SelectorData.self, forKey: .data)
        }
    }
}

struct SelectorData: Decodable {

    struct Variant: Decodable {
        let id: Int
        let text: String
    }

    let selectedId: Int
    let variants: [Variant]
}

struct HzData: Decodable {

    let text: String
}

struct PictureData: Decodable {

    let url: String
    let text: String
}
