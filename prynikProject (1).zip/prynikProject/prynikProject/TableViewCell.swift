//
//  TableViewCell.swift
//  prynikProject
//
//  Created by Олег Ганяхин on 13.10.2020.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var imagePR: UIImageView!
    
    @IBAction func buttonPress(_ sender: Any) {
    }
    @IBOutlet weak var namePR: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
