//
//  AlamoLoader.swift
//  prynikProject
//
//  Created by Олег Ганяхин on 13.10.2020.
//

import Foundation
import Alamofire

protocol alamoLoaderDelegate{
    func loaded3(alamoWeather: ViewResponse)
}

class alamoWeatherLoader {
    
    var delegate: alamoLoaderDelegate?
    
    func loadCategories2(){
     AF.request("https://pryaniky.com/static/json/sample.json").responseJSON {
                response in
                guard  response.error == nil else { return }
            guard let data = response.data else {
                print("No Data")
                return
             }
              do {
                 let decoder = JSONDecoder()
                   do {
                                    let decoder = JSONDecoder()
                                _ = try decoder.decode(ViewResponse.self, from: data)
                                } catch DecodingError.dataCorrupted(let context) {
                                    print(DecodingError.dataCorrupted(context))
                                } catch DecodingError.keyNotFound(let key, let context) {
                                    print(DecodingError.keyNotFound(key,context))
                                } catch DecodingError.typeMismatch(let type, let context) {
                                    print(DecodingError.typeMismatch(type,context))
                                } catch DecodingError.valueNotFound(let value, let context) {
                                    print(DecodingError.valueNotFound(value,context))
                                } catch let error{
                                    print(error)
                                }
                let infoLoad = try decoder.decode(ViewResponse.self, from: data)
                print(infoLoad)
                DispatchQueue.main.async {
                    self.delegate?.loaded3(alamoWeather: infoLoad)
//                    self.delegate?.  loaded2(alamoWeather: infoLoad)
                }
            } catch {
                print(error)
      }
    }
  }
}

