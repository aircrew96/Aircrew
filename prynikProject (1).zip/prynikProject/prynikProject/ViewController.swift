//
//  ViewController.swift
//  prynikProject
//
//  Created by Олег Ганяхин on 13.10.2020.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var items: ViewResponse?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        let loader = alamoWeatherLoader()
        loader.delegate = self
        loader.loadCategories2()
        alamoWeatherLoader().loadCategories2()

        tableView.dataSource = self
       
    }
}
extension ViewController: alamoLoaderDelegate{
    
    func loaded3(alamoWeather : ViewResponse) {
        self.items = alamoWeather
        tableView.reloadData()
    }
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items?.data.count ?? 0
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AlamoCell", for: indexPath) as! TableViewCell
        
        guard  let cat = items?.data[indexPath.row] else { return cell}
//        guard  let item = SelectorData.Variant.Type [indexPath.row] else { return cell}
        
        cell.namePR.text = cat.name.rawValue
        
        cell.imagePR.image = UIImage(data: try! Data(contentsOf: URL(string: "https://pryaniky.com/static/img/logo-a-512.png")!))
        return cell
    }
    
    
    
    
}
